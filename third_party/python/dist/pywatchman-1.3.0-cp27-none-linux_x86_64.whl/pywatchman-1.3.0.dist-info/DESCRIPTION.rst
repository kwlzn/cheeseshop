Connect and query Watchman to discover file changes


